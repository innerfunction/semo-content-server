#!/bin/bash
rm -rf reposDir
rm -rf packages
semocs settings.json
