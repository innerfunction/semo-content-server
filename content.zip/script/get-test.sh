#!/bin/bash

./script/get-content-json.sh github.com jloriente jloriente/jloriente-site 
