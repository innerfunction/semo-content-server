#!/bin/bash

# Clone a repo and get data
#./script/clone-github.sh jloriente anu2Taiwe jloriente/jloriente-site
#./script/get-content-json.sh github.com jloriente jloriente/jloriente-site 

./script/clone-github.sh jloriente anu2Taiwe jloriente/jloriente-site
#./script/clone-github.sh jloriente anu2Taiwe innerfunction/semo-jekyll-demo

#./script/clone-github.sh jloriente anu2Taiwe 0x1f

#./script/clone.sh git.innerfunction.com 22222 jloriente anu2Taiwe julian/thebuildingregulations.com
#./script/clone.sh git.innerfunction.com 22222 jloriente anu2Taiwe jloriente/semo-jekyll-demo
